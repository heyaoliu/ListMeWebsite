module.exports = {
  purge: ["./src/components/**/*.js", "./src/pages/**/*.js"]
};
