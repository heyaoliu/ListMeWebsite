export default {
  debug: process.env.NODE_ENV === 'development',
  siteName: 'Kickoff NextJs',
  projectKey: 'kickoff-nextjs',
};
